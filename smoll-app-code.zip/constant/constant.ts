export const fontHauora = "Hauora";
